package com.doorblock.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import com.doorblock.core.Config
import com.doorblock.core.Prefs
import com.doorblock.core.StreakTimer

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tvDays: TextView
    private lateinit var tvHours: TextView
    private lateinit var tvMinutes: TextView
    private lateinit var tvSeconds: TextView
    private lateinit var tvLock: TextView
    private lateinit var input: EditText

    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        fun label() = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER }

        tvDays = label(); tvHours = label(); tvMinutes = label(); tvSeconds = label()
        tvLock = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }

        input = EditText(this).apply {
            hint = "سایت یا کلمه (مثلا example.com)"
            setSingleLine()
        }
        val add = Button(this).apply {
            text = "افزودن به لیست ممنوع"
            setOnClickListener { addItem() }
        }
        val access = Button(this).apply {
            text = "فعال‌سازی سرویس دسترسی‌پذیری"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(tvDays); addView(tvHours); addView(tvMinutes); addView(tvSeconds)
            addView(tvLock)
            addView(input); addView(add); addView(access)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addItem() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        prefs.custom = prefs.custom + t
        input.setText("")
        Toast.makeText(this, "اضافه شد", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val s = StreakTimer.compute(prefs.startMillis, now)
        tvDays.text = "روز: ${s.days} / ${Config.GOAL_DAYS}"
        tvHours.text = "ساعت: ${s.hours} / 24"
        tvMinutes.text = "دقیقه: ${s.minutes} / 60"
        tvSeconds.text = "ثانیه: ${s.seconds} / 60"
        tvLock.text = if (prefs.isLocked(now))
            "قفل فعال: ${(prefs.lockUntil - now) / 1000} ثانیه مانده"
        else "قفل: آزاد"
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}
