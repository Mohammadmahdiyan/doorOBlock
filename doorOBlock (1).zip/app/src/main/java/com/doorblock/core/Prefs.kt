package com.doorblock.core

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("doorblock", Context.MODE_PRIVATE)

    var startMillis: Long
        get() {
            val v = sp.getLong("start", 0L)
            if (v != 0L) return v
            val now = System.currentTimeMillis()
            sp.edit().putLong("start", now).apply()
            return now
        }
        set(v) { sp.edit().putLong("start", v).apply() }

    var lockUntil: Long
        get() = sp.getLong("lockUntil", 0L)
        set(v) { sp.edit().putLong("lockUntil", v).apply() }

    var custom: Set<String>
        get() = sp.getStringSet("custom", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("custom", v.toSet()).apply() }

    fun isLocked(now: Long = System.currentTimeMillis()) = now < lockUntil

    fun lock(now: Long = System.currentTimeMillis()) {
        lockUntil = now + Config.LOCK_SECONDS * 1000
    }
}
